
Thank you for acquire this asset.

All content in this folder has been created by Israel Maraver Talavera 
Contact address: isramaraver@gmail.com


									----------------------------------------------


Content list:



- Json file

	This folder contains the Json file and the texture atlas. It can be used to directly import the bone animation to the game engine.


- Sprite Sheets

	This folder contains the sprites sheets of all the animations.


- Spriter files
	
	This folder contains the original spriter file where the animations were created, it also includes the images of the character's parts.
	The images and the sprinter file must be in the same folder for proper operation. 

- Krita file
	
	The original file with all the images of the character distributed in layers. Also contains frame by frame animation.

	
										

									----------------------------------------------


These Assets were created with Krita and Spriter Pro.



If you have any questions or problems please do not hesitate to contact me.

